# -*- coding: utf-8 -*-
###############################################################################
#
#    OpenEduCat Inc
#    Copyright (C) 2009-TODAY OpenEduCat Inc(<http://www.openeducat.org>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    module_openeducat_activity = fields.Boolean(string="Activity",related="company_id.module_openeducat_activity",readonly=False)
    module_openeducat_facility = fields.Boolean(string="Facility",related="company_id.module_openeducat_facility",readonly=False)
    module_openeducat_parent = fields.Boolean(string="Parent",related="company_id.module_openeducat_parent",readonly=False)
    module_openeducat_assignment = fields.Boolean(string="Assignment",related="company_id.module_openeducat_assignment",readonly=False)
    module_openeducat_classroom = fields.Boolean(string="Classroom",related="company_id.module_openeducat_classroom",readonly=False)
    module_openeducat_fees = fields.Boolean(string="Fees",related="company_id.module_openeducat_fees",readonly=False)
    module_openeducat_admission = fields.Boolean(string="Admission",related="company_id.module_openeducat_admission",readonly=False)
    module_openeducat_timetable = fields.Boolean(string="Timetable",related="company_id.module_openeducat_timetable",readonly=False)
    module_openeducat_exam = fields.Boolean(string="Exam",related="company_id.module_openeducat_exam",readonly=False)
    module_openeducat_library = fields.Boolean(string="Library",related="company_id.module_openeducat_library",readonly=False)
    module_openeducat_attendance = fields.Boolean(string="Attendance",related="company_id.module_openeducat_attendance",readonly=False)
    module_openeducat_quiz = fields.Boolean(string="Quiz Enterprise",related="company_id.module_openeducat_quiz",readonly=False)
    module_openeducat_discipline = fields.Boolean(related="company_id.module_openeducat_discipline",readonly=False
        ,string="Discipline Enterprise")
    module_openeducat_health_enterprise = fields.Boolean(related="company_id.module_openeducat_health_enterprise",
        string="Health Enterprise",readonly=False)
    module_openeducat_achievement_enterprise = fields.Boolean(related="company_id.module_openeducat_achievement_enterprise",
        string="Achievement Enterprise",readonly=False)
    module_openeducat_activity_enterprise = fields.Boolean(related="company_id.module_openeducat_activity_enterprise",
        string="Activity Enterprise",readonly=False)
    module_openeducat_admission_enterprise = fields.Boolean(related="company_id.module_openeducat_admission_enterprise",
        readonly=False,string="Admission Enterprise")
    module_openeducat_alumni_enterprise = fields.Boolean(related="company_id.module_openeducat_alumni_enterprise",
        string="Alumni Enterprise",readonly=False)
    module_openeducat_alumni_blog_enterprise = fields.Boolean(related="company_id.module_openeducat_alumni_blog_enterprise",
        string="Alumni Blog Enterprise",readonly=False)
    module_openeducat_alumni_event_enterprise = fields.Boolean(related="company_id.module_openeducat_alumni_event_enterprise",
        string="Alumni Event Enterprise",readonly=False)
    module_openeducat_alumni_job_enterprise = fields.Boolean(related="company_id.module_openeducat_alumni_job_enterprise",
        string="Alumni Job Enterprise",readonly=False)
    module_openeducat_job_enterprise = fields.Boolean(related="company_id.module_openeducat_job_enterprise",
        string="Job Enterprise",readonly=False)
    module_openeducat_assignment_enterprise = fields.Boolean(related="company_id.module_openeducat_assignment_enterprise",
        string="Assignment Enterprise",readonly=False)
    module_openeducat_assignment_rubrics = fields.Boolean(related="company_id.module_openeducat_assignment_rubrics",
        string="Assignment Rubrics",readonly=False)
    module_openeducat_attendance_enterprise = fields.Boolean(related="company_id.module_openeducat_attendance_enterprise",
        string="Attendance Enterprise",readonly=False)
    module_openeducat_student_attendance_enterprise = fields.Boolean(related="company_id.module_openeducat_student_attendance_enterprise",
        string="Student Attendance Kiosk",readonly=False)
    module_openeducat_bigbluebutton = fields.Boolean(related="company_id.module_openeducat_bigbluebutton",
        string="Bigbluebutton Enterprise",readonly=False)
    module_openeducat_campus_enterprise = fields.Boolean(related="company_id.module_openeducat_campus_enterprise",
        string="Campus Enterprise",readonly=False)
    module_openeducat_classroom_enterprise = fields.Boolean(related="company_id.module_openeducat_classroom_enterprise",
        string="Classroom Enterprise",readonly=False)
    module_openeducat_exam_enterprise = fields.Boolean(related="company_id.module_openeducat_exam_enterprise",
        string="Exam Enterprise",readonly=False)
    module_openeducat_facility_enterprise = fields.Boolean(related="company_id.module_openeducat_facility_enterprise",
        string="Facility Enterprise",readonly=False)
    module_openeducat_fees_enterprise = fields.Boolean(related="company_id.module_openeducat_fees_enterprise",
        string="Fees Enterprise",readonly=False)
    module_openeducat_fees_plan = fields.Boolean(related="company_id.module_openeducat_fees_plan",
        string="Fees Plan",readonly=False)
    module_openeducat_fees_parent_bridge = fields.Boolean(related="company_id.module_openeducat_fees_parent_bridge",
        string="Fees Parent Bridge",readonly=False)
    module_openeducat_library_barcode = fields.Boolean(related="company_id.module_openeducat_library_barcode",
        string="Library Barcode Enterprise",readonly=False)
    module_openeducat_library_enterprise = fields.Boolean(related="company_id.module_openeducat_library_enterprise",
        string="Library Enterprise",readonly=False)
    module_openeducat_lms = fields.Boolean(related="company_id.module_openeducat_lms",
        string="LMS Enterprise",readonly=False)
    module_openeducat_lms_blog = fields.Boolean(related="company_id.module_openeducat_lms_blog",
        string="LMS Blog Enterprise",readonly=False)
    module_openeducat_lms_forum = fields.Boolean(related="company_id.module_openeducat_lms_forum",
        string="LMS Forum Enterprise",readonly=False)
    module_openeducat_lms_gamification = fields.Boolean(related="company_id.module_openeducat_lms_gamification",
        string="LMS Gamification Enterprise",readonly=False)
    module_openeducat_lms_sale = fields.Boolean(related="company_id.module_openeducat_lms_sale",
        string="LMS Sale Enterprise",readonly=False)
    module_openeducat_lms_survey = fields.Boolean(related="company_id.module_openeducat_lms_survey",
        string="LMS Survey Enterprise",readonly=False)
    module_openeducat_meeting_enterprise = fields.Boolean(related="company_id.module_openeducat_meeting_enterprise",
        string="Meeting Enterprise",readonly=False)
    module_openeducat_online_admission = fields.Boolean(related="company_id.module_openeducat_online_admission",
        string="Online Admission Enterprise", readonly=False)
    module_openeducat_parent_enterprise = fields.Boolean(
        string="Parent Enterprise",readonly=False,related="company_id.module_openeducat_parent_enterprise")
    module_openeducat_placement_enterprise = fields.Boolean(
        string="Placement Enterprise",readonly=False,related="company_id.module_openeducat_placement_enterprise")
    module_openeducat_placement_job_enterprise = fields.Boolean(
        string="Placement Job Enterprise",readonly=False,related="company_id.module_openeducat_placement_job_enterprise")
    module_openeducat_scholarship_enterprise = fields.Boolean(
        string="Scholarship Enterprise",readonly=False,related="company_id.module_openeducat_scholarship_enterprise")
    module_openeducat_timetable_enterprise = fields.Boolean(
        string="Timetable Enterprise",readonly=False,related="company_id.module_openeducat_timetable_enterprise")
    module_openeducat_transportation_enterprise = fields.Boolean(
        string="Transportation Enterprise",readonly=False,related="company_id.module_openeducat_transportation_enterprise")
    module_openeducat_lesson = fields.Boolean(
        string="Lesson Enterprise",readonly=False,related="company_id.module_openeducat_lesson")
    module_openeducat_skill_enterprise = fields.Boolean(
        string="Skill Enterprise",readonly=False,related="company_id.module_openeducat_skill_enterprise")
    module_openeducat_lms_website = fields.Boolean(
        string="LMS Website",readonly=False,related="company_id.module_openeducat_lms_website")
    module_openeducat_assignment_grading_enterprise = fields.Boolean(
        string="Assignment Grading Enterprise",readonly=False,related="company_id.module_openeducat_assignment_grading_enterprise")
    module_openeducat_assignment_grading_bridge = fields.Boolean(
        string="Assignment Grading Bridge",readonly=False,related="company_id.module_openeducat_assignment_grading_bridge")
    module_openeducat_fees_on_session = fields.Boolean(
        string="Fees On Session",readonly=False,related="company_id.module_openeducat_fees_on_session")
    module_openeducat_fees_on_duration = fields.Boolean(
        string="Fees On Duration",readonly=False,related="company_id.module_openeducat_fees_on_duration")
    module_openeducat_lms_admission = fields.Boolean(
        string="LMS Admission",readonly=False,related="company_id.module_openeducat_lms_admission")
    module_openeducat_backend_theme = fields.Boolean(
        string="Backend Theme",readonly=False,related="company_id.module_openeducat_backend_theme")
    module_openeducat_crm_enterprise = fields.Boolean(
        string="CRM Enterprise",readonly=False,related="company_id.module_openeducat_crm_enterprise")
    module_openeducat_dashboard_kpi = fields.Boolean(
        string="Dashboard KPI",readonly=False,related="company_id.module_openeducat_dashboard_kpi")
    module_openeducat_digital_library = fields.Boolean(
        string="Digital Library",readonly=False,related="company_id.module_openeducat_digital_library")
    module_openeducat_event_enterprise = fields.Boolean(
        string="Event Enterprise",readonly=False,related="company_id.module_openeducat_event_enterprise")
    module_openeducat_exam_gpa_enterprise = fields.Boolean(
        string="Exam GPA Enterprise",readonly=False,related="company_id.module_openeducat_exam_gpa_enterprise")
    module_openeducat_exam_grading_bridge = fields.Boolean(
        string="Exam Grading Bridge",readonly=False,related="company_id.module_openeducat_exam_grading_bridge")
    module_openeducat_googlemeet = fields.Boolean(
        string="Google Meet",readonly=False,related="company_id.module_openeducat_googlemeet")
    module_openeducat_grading = fields.Boolean(
        string="Grading",readonly=False,related="company_id.module_openeducat_grading")
    module_openeducat_jitsi_enterprise = fields.Boolean(
        string="Jitsi Enterprise",readonly=False,related="company_id.module_openeducat_jitsi_enterprise")
    module_openeducat_quiz_anti_cheating = fields.Boolean(
        string="Quiz Anti Cheating",readonly=False,related="company_id.module_openeducat_quiz_anti_cheating")
    module_openeducat_skypemeet = fields.Boolean(
        string="Skype Meet",readonly=False,related="company_id.module_openeducat_skypemeet")
    module_openeducat_student_progress_enterprise = fields.Boolean(
        string="Student Progress Enterprise",readonly=False,related="company_id.module_openeducat_student_progress_enterprise")
    module_openeducat_subject_material_allocation = fields.Boolean(
        string="Subject Material Allocation",readonly=False,related="company_id.module_openeducat_subject_material_allocation")
    module_openeducat_teams = fields.Boolean(
        string="Teams",readonly=False,related="company_id.module_openeducat_teams")
    module_openeducat_zoom = fields.Boolean(
        string="Zoom",readonly=False,related="company_id.module_openeducat_zoom")
    module_openeducat_student_leave_enterprise = fields.Boolean(
        string="Student Leave",readonly=False,related="company_id.module_openeducat_student_leave_enterprise")
    module_openeducat_notice_board_enterprise = fields.Boolean(
        string="Notice Board Enterprise",readonly=False,related="company_id.module_openeducat_notice_board_enterprise")
    module_openeducat_student_skill_assessment = fields.Boolean(
        string="Skill Assessment Enterprise",readonly=False,related="company_id.module_openeducat_student_skill_assessment")
    module_openeducat_lms_h5p = fields.Boolean(
        string="LMS H5P Enterprise",readonly=False,related="company_id.module_openeducat_lms_h5p")
    module_openeducat_online_appointment = fields.Boolean(
        string="Online Appointment Enterprise",readonly=False,related="company_id.module_openeducat_online_appointment")
    module_openeducat_grievance_enterprise = fields.Boolean(
        string="Grievance",readonly=False,related="company_id.module_openeducat_grievance_enterprise")
    module_openeducat_secure = fields.Boolean(
        string="Secure QR",readonly=False,related="company_id.module_openeducat_secure")
    module_openeducat_mass_subject_registration = fields.Boolean(
        string="Mass Subject Registration",readonly=False,related="company_id.module_openeducat_mass_subject_registration")
    module_openeducat_attendance_report_xlsx = fields.Boolean(
        string="Attendance Xlsx Report",readonly=False,related="company_id.module_openeducat_attendance_report_xlsx")
    module_openeducat_asset_request_enterprise = fields.Boolean(
        string="Asset Request Enterprise",readonly=False,related="company_id.module_openeducat_asset_request_enterprise")
    module_openeducat_lms_interactive_video = fields.Boolean(
        string="Lms Interactive Video",readonly=False,related="company_id.module_openeducat_lms_interactive_video")
    module_openeducat_lms_drag_into_text = fields.Boolean(
        string="Lms Drag Into Text",readonly=False,related="company_id.module_openeducat_lms_drag_into_text")
    module_openeducat_lms_match_following = fields.Boolean(
        string="Lms Match Following",readonly=False,related="company_id.module_openeducat_lms_match_following")
    module_openeducat_lms_match_images = fields.Boolean(
        string="Lms Match Images",readonly=False,related="company_id.module_openeducat_lms_match_images")
    module_openeducat_lms_multiple_choice = fields.Boolean(
        string="Lms Multiple Choice",readonly=False,related="company_id.module_openeducat_lms_multiple_choice")
    module_openeducat_lms_numeric = fields.Boolean(
        string="Lms Numeric",readonly=False,related="company_id.module_openeducat_lms_numeric")
    module_openeducat_lms_sort_paragraphs = fields.Boolean(
        string="Lms Sort Paragraphs",readonly=False,related="company_id.module_openeducat_lms_sort_paragraphs")
    module_openeducat_quiz_drag_into_text = fields.Boolean(
        string="Quiz Drag Into Text",readonly=False,related="company_id.module_openeducat_quiz_drag_into_text")
    module_openeducat_quiz_match_following = fields.Boolean(
        string="Quiz Match Following",readonly=False,related="company_id.module_openeducat_quiz_match_following")
    module_openeducat_quiz_match_images = fields.Boolean(
        string="Quiz Match Images",readonly=False,related="company_id.module_openeducat_quiz_match_images")
    module_openeducat_quiz_multiple_choice = fields.Boolean(
        string="Quiz Multiple Choice,readonly=False",related="company_id.module_openeducat_quiz_multiple_choice")
    module_openeducat_quiz_numeric = fields.Boolean(
        string="Quiz Numeric",readonly=False,related="company_id.module_openeducat_quiz_numeric")
    module_openeducat_quiz_sort_paragraphs = fields.Boolean(
        string="Quiz Sort Paragraphs",readonly=False,related="company_id.module_openeducat_quiz_sort_paragraphs")
    module_openeducat_live = fields.Boolean(
        string="Live Meeting",readonly=False,related="company_id.module_openeducat_live")
    module_openeducat_live_assignment = fields.Boolean(
        string="Live Meeting Assignment",readonly=False,related="company_id.module_openeducat_live_assignment")
    module_openeducat_live_attendance = fields.Boolean(
        string="Live Meeting Attendance",readonly=False,related="company_id.module_openeducat_live_attendance")
    module_openeducat_live_attentiveness = fields.Boolean(
        string="Live Meeting Attentiveness",readonly=False,related="company_id.module_openeducat_live_attentiveness")
    module_openeducat_attendance_face_recognition = fields.Boolean(
        string="Attendance Face Recognition",readonly=False,related="company_id.module_openeducat_attendance_face_recognition")
    module_openeducat_omr = fields.Boolean(
        string="OMR",readonly=False,related="company_id.module_openeducat_omr")
    module_openeducat_auto_database_backup = fields.Boolean(
        string="Database Backup to Local Server",readonly=False,related="company_id.module_openeducat_auto_database_backup")
    module_openeducat_auto_database_backup_dropbox = fields.Boolean(
        string="Database Backup to Dropbox",readonly=False,related="module_openeducat_auto_database_backup")
    module_openeducat_auto_database_backup_ftp = fields.Boolean(
        string="Database Backup to Remote FTP Server",readonly=False,related="module_openeducat_auto_database_backup")
    module_openeducat_auto_database_backup_google_drive = fields.Boolean(
        string="Database Backup to Google Drive",readonly=False,related="module_openeducat_auto_database_backup")
    module_openeducat_auto_database_backup_onedrive = fields.Boolean(
        string="Database Backup to Onedrive",readonly=False,related="module_openeducat_auto_database_backup")
    module_openeducat_auto_database_backup_sftp = fields.Boolean(
        string="Database Backup to Remote SFTP Server",readonly=False,related="module_openeducat_auto_database_backup")
    attendance_subject_generic = fields.Selection([('subject', 'Subject Wise'), ('generic', 'Generic')],
                                                  help="Subject-specific attendance will be gathered during a "
                                                       "particular session, whereas general attendance will be "
                                                       "collected by one responsible faculty member for the "
                                                       "entire day.",
                                                  related="company_id.attendance_subject_generic",readonly=1,
                                                  default='subject')
